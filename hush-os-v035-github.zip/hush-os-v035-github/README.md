# Hush OS v0.35

Static GitHub Pages-ready build.

## Structure

- `index.html` - the app shell and JavaScript
- `assets/room-base.png` - illustrated room shell
- `assets/hush-tv-asset.png` - production TV asset

## Run locally

Open `index.html` directly in a browser, or run a simple static server from this folder:

```bash
python -m http.server 8000
```

Then open `http://localhost:8000`.

## Deploy on GitHub Pages

Push this folder to a GitHub repository, then enable GitHub Pages for the branch that contains `index.html`.
